-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 04:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotelms`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `checkInDate` date NOT NULL,
  `checkOutDate` date NOT NULL,
  `room_no` int(11) NOT NULL,
  `room_type` varchar(25) NOT NULL,
  `checked_in` varchar(3) NOT NULL DEFAULT 'NO',
  `reserved_on` datetime NOT NULL DEFAULT current_timestamp(),
  `username` varchar(50) NOT NULL,
  `booking_id` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `name`, `email`, `checkInDate`, `checkOutDate`, `room_no`, `room_type`, `checked_in`, `reserved_on`, `username`, `booking_id`, `price`) VALUES
(1, 'Melusi Nyoni', 'mail@mail.com', '2024-05-30', '2024-05-31', 101, 'Standard (Single)', 'NO', '2024-05-29 11:24:56', 'admin', '29052024025456', 600),
(2, 'Melusi Nyoni', 'mail@mail.com', '2024-05-30', '2024-05-31', 102, 'Standard (Single)', 'NO', '2024-05-29 11:24:56', 'admin', '29052024025456', 600),
(3, 'Gina', 'gina@mail.com', '2024-05-30', '2024-05-31', 301, 'Deluxe (Single)', 'NO', '2024-05-29 11:36:25', 'gigi', '29052024030625', 1100);

-- --------------------------------------------------------

--
-- Table structure for table `contactform`
--

CREATE TABLE `contactform` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL,
  `recieved_at` datetime NOT NULL DEFAULT current_timestamp(),
  `replied` varchar(3) NOT NULL DEFAULT 'NO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loginform`
--

CREATE TABLE `loginform` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `admin` varchar(3) NOT NULL DEFAULT 'NO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loginform`
--

INSERT INTO `loginform` (`id`, `fname`, `lastname`, `email`, `username`, `password`, `created_at`, `admin`) VALUES
(1, 'Admin', '1', 'admin@gmail.com', 'admin', '$2y$10$hhfdE3DZIMYCs.TUwr2lY.02ybw9G4.ph7QmMfs3St7196jkgcZ..', '2021-05-29 21:24:35', 'YES'),
(2, 'Abisha', '', 'abisha@abishahotels.com', 'abi', '$2y$10$t3xLHsqWH6vJrTsrn0P04eyVh4l2rd3YrXi1DrQKQ1rMoZ5yjUqe.', '2024-05-28 10:22:16', 'NO'),
(3, 'Melusi', '', 'nyoni@gmail.com', 'tomara', '$2y$10$TQPGXZBeY8B/xEUxMqp0DOyI18KoNIIjkeSirvvUF1Mo.7.W/Mipq', '2024-05-28 10:33:17', 'NO'),
(4, 'Gina', '', 'gina@mail.com', 'gigi', '$2y$10$I3tD7tiPlkoeUeZCT4e.WOOk9biPcQVJ6wKiyWyFwFgNQcpXhON2e', '2024-05-29 11:34:04', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `room_type` varchar(25) NOT NULL,
  `price` int(11) NOT NULL,
  `discountedPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_no`, `room_type`, `price`, `discountedPrice`) VALUES
(1, 101, 'Standard Single', 600, 0),
(2, 102, 'Standard Single', 600, 0),
(3, 103, 'Standard Single', 600, 0),
(4, 104, 'Standard Single', 600, 0),
(5, 105, 'Standard Single', 600, 0),
(6, 201, 'Standard Double', 800, 0),
(7, 202, 'Standard Double', 800, 0),
(8, 203, 'Standard Double', 800, 0),
(9, 204, 'Standard Double', 800, 0),
(10, 205, 'Standard Double', 800, 0),
(11, 301, 'Deluxe Single', 1100, 0),
(12, 302, 'Deluxe Single', 1100, 0),
(13, 303, 'Deluxe Single', 1100, 0),
(14, 304, 'Deluxe Single', 1100, 0),
(15, 305, 'Deluxe Single', 1100, 0),
(16, 401, 'Deluxe Double', 1500, 0),
(17, 402, 'Deluxe Double', 1500, 0),
(18, 403, 'Deluxe Double', 1500, 0),
(19, 404, 'Deluxe Double', 1500, 0),
(20, 405, 'Deluxe Double', 1500, 0),
(21, 501, 'Deluxe Suite', 2146, 0),
(22, 502, 'Deluxe Suite', 2146, 0),
(23, 503, 'Deluxe Suite', 2146, 0),
(24, 504, 'Deluxe Suite', 2146, 0),
(25, 505, 'Deluxe Suite', 2146, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactform`
--
ALTER TABLE `contactform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loginform`
--
ALTER TABLE `loginform`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contactform`
--
ALTER TABLE `contactform`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loginform`
--
ALTER TABLE `loginform`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
