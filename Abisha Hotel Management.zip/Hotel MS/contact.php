<?php
require_once "config.php";
session_start();
$name = $email = $message = "";
$name_err = $email_err = $message_err = "";
//name validation
if($_SERVER['REQUEST_METHOD']=="POST"){
    //Check if name is empty
    if(empty(trim($_POST['name']))){
        $name_err = "Name cannot be blank";
    }
    else{
        $sql = "SELECT id FROM contactform WHERE name = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt){
            mysqli_stmt_bind_param($stmt, "s", $param_name);

            //Set the value of param name
            $param_name = trim($_POST['name']);
            //Try to execute the statement
            if(mysqli_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                $name = trim($_POST['name']);
            }
            else{
                echo "<script>alert('Something went wrong');</script>";
            }
        }
    }

    //Check if message is empty
    if(empty(trim($_POST['message']))){
        $message_err = "Message cannot be blank";
    }
    else{
        $sql = "SELECT id FROM contactform WHERE message = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt){
            mysqli_stmt_bind_param($stmt, "s", $param_message);

            //Set the value of param message
            $param_message = trim($_POST['message']);
            //Try to execute the statement
            if(mysqli_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                $message = trim($_POST['message']);
            }
            else{
                echo "<script>alert('Something went wrong');</script>";
            }
        }
    }
    
    //Check if email is empty
    if(empty(trim($_POST['email']))){
        $email_err = "Email cannot be blank";
    }
    else{
        $sql = "SELECT id FROM contactform WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt){
            mysqli_stmt_bind_param($stmt, "s", $param_email);

            //Set the value of param email
            $param_email = trim($_POST['email']);
            //Try to execute the statement
            if(mysqli_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                $email = trim($_POST['email']);
            }
            else{
                echo "<script>alert('Something went wrong');</script>";
            }
        }
    }
    //If there were no errors then insert the values into the database
    if(empty($name_err) && empty($email_err) && empty($message_err)){
        $sql = "INSERT INTO contactform (name, email, message) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt){
            mysqli_stmt_bind_param($stmt, "sss", $param_name, $param_email, $param_message);
            $param_name = $name;
            $param_email = $email;
            $param_message = $message;
            if(mysqli_stmt_execute($stmt)){
                echo "<script>alert('Submitted Successfully')</script>";
            }
            else{
                echo "<script>alert('Something went wrong.. Cannot Redirect');</script>";
            }
        }
        else{
            echo 'Something went wrong';
        }
    }
    else{
        if(!empty($name_err)){
            echo "<script>alert('$name_err')</script>";
        }
        elseif(!empty($email_err)){
            echo "<script>alert('$email_err')</script>";
        }
        elseif(!empty($message_err)){
            echo "<script>alert('$username_err')</script>";
        }
    }
    mysqli_close($conn);
}


?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css" />
    <title>Abisha Hotels | Contacts</title>
	<link rel="shortcut icon" href="images/favicon.png">
	<link rel="stylesheet" href="css/superfish.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	<link rel="stylesheet" href="css/themify-icons.css">
	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/flexslider.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="js/modernizr-2.6.2.min.js"></script>
	

  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Abisha Hotels Booking</a>
            <ul class="navbar-nav">
            <?php if(!isset($_SESSION['username'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="register.php">Register <i class="fa fa-user-plus" aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login <i class="fa fa-sign-in" aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="contact.php">Contact <i class="fa fa-envelope-o" aria-hidden="true"></i></a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="accountInfo.php"><?php echo $_SESSION['fname']?> <i class="fa fa-user" aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="home.php">Home</i></a>
                </li>
                <?php if($_SESSION["admin"]=='YES'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Admin</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="contact.php">Contact <i class="fa fa-envelope-o" aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout <i class="fa fa-sign-out" aria-hidden="true"></i></a>
                </li>
            <?php endif; ?>
            </ul>
        </div>
    </nav>

    
    <div class="container-fluid">
        <hr>
  <h1>Contact Us</h1>
  <hr>
  <p>We're here to help! Contact us with any questions or feedback.</p>
  <p>Our team is dedicated to providing excellent customer service. Reach out via phone, email, or the contact form below. We look forward to hearing from you! </p>
  <div class="row">
    <div class="col-sm-6" style="background-color:white;">
    <div style="text-decoration:none; overflow:hidden;max-width:100%;width:660px;height:500px;">
    <div id="embed-map-display" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=victoria+falls&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"></iframe></div>
        <a class="google-maps-html" rel="nofollow" href="https://www.bootstrapskins.com/themes" id="get-data-for-map">premium bootstrap themes</a><style>#embed-map-display img{max-height:none;max-width:none!important;background:none!important;}</style>
    </div>
</div>
    <div class="col-sm-6" style="background-color:white;">
    <form action="" method="post">
        <div class="row">
            <div class="col-6">
                <label for="inputname" class="form-label">Name</label>
                <input type="text" class="form-control" name="name" id="inputname">
            </div>
            <div class="col-6">
                <label for="inputEmail4" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" id="inputEmail4">
            </div>
        </div>
        <br>
        <div class="col-12">
            <label for="message" class="form-label">Message</label>
            <textarea type="text" class="form-control" name="message" style="height: 300px;text-align: top;"></textarea>
        </div>
        <br>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>
  </div>
</div>

</div>

<footer id="footer" class="fh5co-bg-color">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="copyright">
						<p><small>&copy; Abisha Hotels<br> All Rights Reserved. <br>
						Designed by <a href="#" target="_blank">Abisha Services</a> <br> Gallery Images: <a href="#" target="_blank">Abisha</a></small></p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="row">
						<div class="col-md-3">
							<h3>Company</h3>
							<ul class="link">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Hotels</a></li>
								<li><a href="#">Customer Care</a></li>
								<li><a href="#">Contact Us</a></li>
							</ul>
						</div>
						<div class="col-md-3">
							<h3>Our Facilities</h3>
							<ul class="link">
								<li><a href="#">Resturant</a></li>
								<li><a href="#">Bars</a></li>
								<li><a href="#">Pick-up</a></li>
								<li><a href="#">Swimming Pool</a></li>
								<li><a href="#">Spa</a></li>
								<li><a href="#">Gym</a></li>
							</ul>
						</div>
						<div class="col-md-6">
							<h3>Subscribe</h3>
							<p>Subscribe to stay updated on our latest news, promotions, and exclusive offers!</p>
							<form action="#" id="form-subscribe">
								<div class="form-field">
									<input type="email" placeholder="Email Address" id="email">
									<input type="submit" id="submit" value="Send">
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<ul class="social-icons">
						<li>
							<a href="#"><i class="icon-twitter-with-circle"></i></a>
							<a href="#"><i class="icon-facebook-with-circle"></i></a>
							<a href="#"><i class="icon-instagram-with-circle"></i></a>
							<a href="#"><i class="icon-linkedin-with-circle"></i></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer>

	</div>
	</div>
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countTo.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/bootstrap-datepicker.min.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<script src="js/jquery.flexslider-min.js"></script>
	<script src="js/custom.js"></script>

</body>
</html>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
  </body>
</html>