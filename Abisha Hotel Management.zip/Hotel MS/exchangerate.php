<?php
include dashboard.php;
    require_once "config.php";
    session_start();

    if(isset($_POST['submit'])){
       /* if (empty($_POST["country"])){
            $countryErr = "Country is required";
        }else{*/
            $country = $_POST["country"];
            $rate = $_POST["rate"];

            echo $country;
        
        }
       
       /* $sql = "UPDATE exhangerate SET rate_against_usd = $rate WHERE country = '$country'";
        if (mysqli_query($conn, $sql)){
            $f = 1;
        }
    
    }*/
    ?>